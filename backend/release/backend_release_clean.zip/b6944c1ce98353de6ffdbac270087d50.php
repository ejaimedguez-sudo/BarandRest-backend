<html>
<body>
  <p>Buen día,</p>
  <p>Adjunto el reporte solicitado.</p>
  <p>Saludos.</p>
</body>
</html>
<html>
<body>
  <p>Hola,</p>
  <p>Tu reporte solicitado está adjunto: <strong><?php echo e($filename); ?></strong>.</p>
  <p>Saludos,<br/>BarandRest</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\apps\BarandRest\backend\resources\views\emails\report_ready.blade.php ENDPATH**/ ?>