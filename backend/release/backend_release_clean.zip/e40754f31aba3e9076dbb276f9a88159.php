<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ccc; padding: 6px; font-size: 12px; }
    th { background: #f2f2f2; }
  </style>
</head>
<body>
  <h2>Reporte - <?php echo e(date('Y-m-d H:i')); ?></h2>
  <?php if(file_exists(public_path('images/logo.png'))): ?>
    <div><img src="<?php echo e(public_path('images/logo.png')); ?>" alt="Logo" style="height:50px"></div>
  <?php endif; ?>
  <table>
    <thead>
      <tr>
        <?php if(!empty($rows) && is_array($rows) && isset($rows[0]) && is_array($rows[0])): ?>
          <?php $__currentLoopData = array_keys($rows[0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($h); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <th>Dato</th>
        <?php endif; ?>
      </tr>
    </thead>
    <tbody>
      <?php if(!empty($rows) && is_array($rows)): ?>
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <?php if(is_array($r)): ?>
              <?php $__currentLoopData = $r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($c); ?></td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <td><?php echo e(is_scalar($r) ? $r : json_encode($r)); ?></td>
            <?php endif; ?>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($totals) && is_array($totals)): ?>
          <tr>
            <?php if(!empty($rows) && is_array($rows[0])): ?>
              <?php $__currentLoopData = array_keys($rows[0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td style="font-weight:bold"><?php echo e($totals[$k] ?? ''); ?></td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <td style="font-weight:bold">Totales: <?php echo e(implode(' | ', $totals)); ?></td>
            <?php endif; ?>
          </tr>
        <?php endif; ?>
      <?php endif; ?>
    </tbody>
  </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\apps\BarandRest\backend\resources\views/reports/pdf.blade.php ENDPATH**/ ?>