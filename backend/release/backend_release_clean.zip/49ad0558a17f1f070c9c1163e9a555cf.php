<html>
<body>
    <p><?php echo e($message); ?></p>
    <p>If you received this, SMTP and mail sending are configured.</p>
    <p>Regards,<br/>BarAndRest</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\apps\BarandRest\backend\resources\views\emails\test.blade.php ENDPATH**/ ?>